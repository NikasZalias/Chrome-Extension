﻿angular.module('app', [])
    .run(function ($rootScope) {
        $rootScope.message = "Hello Angular again!";
});

