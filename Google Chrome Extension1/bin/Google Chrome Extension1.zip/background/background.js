﻿chrome.browserAction.onClicked.addListener(function (tab) {
    alert("Hello Chrome!");
});